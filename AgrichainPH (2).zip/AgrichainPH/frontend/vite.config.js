import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      "/register": "http://localhost:5000",
      "/product": "http://localhost:5000",
      "/transfer": "http://localhost:5000"
    }
  }
});
