import { useState } from "react";

const initialState = {
  name: "",
  origin: "",
  quantity: "",
  productId: "",
  transferId: "",
  newOwner: ""
};

function App() {

  const [form, setForm] = useState(initialState);

  const [status, setStatus] = useState({
    message: "",
    type: ""
  });

  const [product, setProduct] = useState(null);

  const updateField = (field) => (event) => {
    setForm({
      ...form,
      [field]: event.target.value
    });
  };

  const resetStatus = () => {
    setStatus({
      message: "",
      type: ""
    });
  };



  // REGISTER PRODUCT
  const registerProduct = async () => {

    resetStatus();

    try {

      // CONNECT TO METAMASK
      if (!window.ethereum) {

        setStatus({
          message: "MetaMask not installed.",
          type: "error"
        });

        return;
      }

      await window.ethereum.request({
        method: "eth_requestAccounts"
      });


      // VALIDATION
      if (
        !form.name ||
        !form.origin ||
        Number(form.quantity) <= 0
      ) {

        setStatus({
          message: "Please complete all register fields.",
          type: "error"
        });

        return;
      }


      // SEND TO BACKEND
      const response = await fetch(
        "http://localhost:5000/register",
        {
          method: "POST",

          headers: {
            "Content-Type": "application/json"
          },

          body: JSON.stringify({
            name: form.name,
            origin: form.origin,
            quantity: Number(form.quantity)
          })
        }
      );

      const data = await response.json();

      if (!response.ok) {

        setStatus({
          message: data.error || "Registration failed.",
          type: "error"
        });

        return;
      }

      setStatus({
        message: "Product registered successfully.",
        type: "success"
      });

      setForm({
        ...form,
        name: "",
        origin: "",
        quantity: ""
      });

      setProduct(null);

    } catch (error) {

      console.error(error);

      setStatus({
        message: error.message,
        type: "error"
      });
    }
  };



  // VIEW PRODUCT
  const viewProduct = async () => {

    resetStatus();

    setProduct(null);

    try {

      if (!form.productId) {

        setStatus({
          message: "Enter a product ID.",
          type: "error"
        });

        return;
      }

      const response = await fetch(
        `http://localhost:5000/product/${form.productId}`
      );

      const data = await response.json();

      if (!response.ok) {

        setStatus({
          message: data.error || "Could not retrieve product.",
          type: "error"
        });

        return;
      }

      setProduct(data);

    } catch (error) {

      console.error(error);

      setStatus({
        message: error.message,
        type: "error"
      });
    }
  };



  // TRANSFER OWNERSHIP
  const transferOwnership = async () => {

    resetStatus();

    try {

      if (!window.ethereum) {

        setStatus({
          message: "MetaMask not installed.",
          type: "error"
        });

        return;
      }

      await window.ethereum.request({
        method: "eth_requestAccounts"
      });

      if (
        !form.transferId ||
        !form.newOwner
      ) {

        setStatus({
          message: "Enter product ID and new owner.",
          type: "error"
        });

        return;
      }

      const response = await fetch(
        "http://localhost:5000/transfer",
        {
          method: "POST",

          headers: {
            "Content-Type": "application/json"
          },

          body: JSON.stringify({
            id: form.transferId,
            newOwner: form.newOwner
          })
        }
      );

      const data = await response.json();

      if (!response.ok) {

        setStatus({
          message: data.error || "Transfer failed.",
          type: "error"
        });

        return;
      }

      setStatus({
        message: data.message,
        type: "success"
      });

      setForm({
        ...form,
        transferId: "",
        newOwner: ""
      });

    } catch (error) {

      console.error(error);

      setStatus({
        message: error.message,
        type: "error"
      });
    }
  };



  return (

    <div className="app-shell">

      <header className="topbar">

        <div className="brand-block">
          <h1>AgriChainPH</h1>
        </div>

      </header>



      <main className="content-grid">


        {/* REGISTER */}
        <section className="panel">

          <h2>Register Product</h2>

          <label>Product Name</label>

          <input
            value={form.name}
            onChange={updateField("name")}
            placeholder="Product name"
          />

          <label>Origin</label>

          <input
            value={form.origin}
            onChange={updateField("origin")}
            placeholder="Origin"
          />

          <label>Quantity</label>

          <input
            value={form.quantity}
            onChange={updateField("quantity")}
            type="number"
            placeholder="Quantity"
          />

          <button onClick={registerProduct}>
            Register Product
          </button>

        </section>



        {/* VIEW PRODUCT */}
        <section className="panel">

          <h2>View Product</h2>

          <label>Product ID</label>

          <input
            value={form.productId}
            onChange={updateField("productId")}
            placeholder="Product ID"
          />

          <button onClick={viewProduct}>
            View Product
          </button>

          {product && (

            <div>

              <p>ID: {product.id}</p>

              <p>Name: {product.name}</p>

              <p>Origin: {product.origin}</p>

              <p>Quantity: {product.quantity}</p>

              <p>Owner: {product.owner}</p>

            </div>
          )}

        </section>



        {/* TRANSFER */}
        <section className="panel">

          <h2>Transfer Ownership</h2>

          <label>Product ID</label>

          <input
            value={form.transferId}
            onChange={updateField("transferId")}
            placeholder="Product ID"
          />

          <label>New Owner Address</label>

          <input
            value={form.newOwner}
            onChange={updateField("newOwner")}
            placeholder="Wallet address"
          />

          <button onClick={transferOwnership}>
            Transfer Ownership
          </button>

        </section>



        {/* STATUS */}
        {status.message && (

          <div>

            <h3>{status.message}</h3>

          </div>
        )}

      </main>

    </div>
  );
}

export default App;