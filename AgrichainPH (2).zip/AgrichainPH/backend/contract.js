const { ethers } = require("ethers");

const contractAddress =
"0xB2F5bf9442f9540c9Dc3106276FD2c5d86Ff6E87";

const abi = [

"function registerProduct(string memory _name, string memory _origin, uint256 _quantity) public",

"function getProduct(uint256 _id) public view returns(uint256,string memory,string memory,uint256,address)",

"function transferOwnership(uint256 _id, address _newOwner) public"

];

const provider =
new ethers.JsonRpcProvider(
"http://127.0.0.1:7545"
);

const privateKey =
"0x0458e998f80199a1a4d963294b78678c46ecaccebccc496ddce09acb2515cc9a";

const wallet =
new ethers.Wallet(privateKey, provider);

const contract =
new ethers.Contract(
contractAddress,
abi,
wallet
);

module.exports = contract;