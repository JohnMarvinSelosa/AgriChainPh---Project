// Quick test to see if the backend can start
console.log("Testing backend setup...");

try {
  console.log("✓ Checking dependencies...");
  const express = require("express");
  console.log("✓ Express loaded");
  
  const cors = require("cors");
  console.log("✓ CORS loaded");
  
  console.log("✓ All dependencies OK");
  
  console.log("\n⚠️  Checking blockchain connection...");
  const contract = require("./contract");
  console.log("✓ Contract module loaded");
  
  console.log("\n✓ Backend setup successful!");
  console.log("\nNEXT STEPS:");
  console.log("1. Make sure Ganache is running on http://127.0.0.1:7545");
  console.log("2. Then run: node server.js");
  
} catch (error) {
  console.error("✗ Error:", error.message);
  console.log("\nTROUBLESHOOTING:");
  if (error.message.includes("ECONNREFUSED")) {
    console.log("❌ Cannot connect to blockchain at http://127.0.0.1:7545");
    console.log("   Please ensure Ganache is running!");
  } else {
    console.log("Check the error above and install missing dependencies if needed.");
  }
  process.exit(1);
}
